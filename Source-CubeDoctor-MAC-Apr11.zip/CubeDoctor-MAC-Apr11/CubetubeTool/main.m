//
//  main.m
//  CubetubeTool
//
//  Created by luozhuang on 15-12-3.
//  Copyright (c) 2015 Cubetube. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
